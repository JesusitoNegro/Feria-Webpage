// Función para mostrar u ocultar campos según el método de pago seleccionado
function togglePaymentFields() {
    const metodo = document.getElementById('metodo').value;
    
    // Ocultar todos los campos de pago
    document.getElementById('tarjetaFields').style.display = 'none';
    document.getElementById('transferenciaFields').style.display = 'none';
    document.getElementById('paypalFields').style.display = 'none';
  
    // Mostrar los campos correspondientes según el método de pago
    if (metodo === 'tarjeta') {
      document.getElementById('tarjetaFields').style.display = 'block';
    } else if (metodo === 'transferencia') {
      document.getElementById('transferenciaFields').style.display = 'block';
    } else if (metodo === 'paypal') {
      document.getElementById('paypalFields').style.display = 'block';
    }
  }
  
  // Validación del formulario antes de enviarlo
  document.getElementById('donationForm').addEventListener('submit', function(event) {
    const metodo = document.getElementById('metodo').value;
    
    if (metodo === 'tarjeta') {
      // Validar número de tarjeta (solo números y longitud correcta)
      const tarjetaNumero = document.getElementById('tarjetaNumero').value;
      if (!/^\d{4}-\d{4}-\d{4}-\d{4}$/.test(tarjetaNumero)) {
        alert('Por favor, ingrese un número de tarjeta válido.');
        event.preventDefault();
      }
  
      // Validar CVV (3 dígitos)
      const tarjetaCVV = document.getElementById('tarjetaCVV').value;
      if (!/^\d{3}$/.test(tarjetaCVV)) {
        alert('El CVV debe tener 3 dígitos.');
        event.preventDefault();
      }
    }
  
    if (metodo === 'transferencia') {
      const cuentaBancaria = document.getElementById('cuentaBancaria').value;
      if (cuentaBancaria.trim() === '') {
        alert('Por favor, ingrese el número de cuenta bancaria.');
        event.preventDefault();
      }
    }
  
    if (metodo === 'paypal') {
      const paypalEmail = document.getElementById('paypalEmail').value;
      if (!paypalEmail) {
        alert('Por favor, ingrese su correo electrónico de PayPal.');
        event.preventDefault();
      }
    }
  });

// Validación del formulario antes de enviarlo
document.getElementById('reservationForm').addEventListener('submit', function(event) {
  // Validar número de tarjeta (solo números y longitud correcta)
  const tarjetaNumero = document.getElementById('tarjetaNumero').value;
  if (!/^\d{4}-\d{4}-\d{4}-\d{4}$/.test(tarjetaNumero)) {
    alert('Por favor, ingrese un número de tarjeta válido.');
    event.preventDefault();
  }

  // Validar CVV (3 dígitos)
  const tarjetaCVV = document.getElementById('tarjetaCVV').value;
  if (!/^\d{3}$/.test(tarjetaCVV)) {
    alert('El CVV debe tener 3 dígitos.');
    event.preventDefault();
  }
});
